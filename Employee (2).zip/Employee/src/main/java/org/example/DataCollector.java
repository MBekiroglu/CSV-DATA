package org.example;

import java.util.ArrayList;
import java.util.HashMap;

public class DataCollector {
    static public HashMap<String, Employee> cleanData = new HashMap<>();
    static public ArrayList<Employee> corruptData = new ArrayList<Employee>();

    DataCollector() {}
}
